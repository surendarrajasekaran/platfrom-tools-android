This contains an envoy configuration that can be used during development.
It is configured as a gRPC proxy to the emulator running on port 8554.
It will redirect the rest to the npm develop endpoint on port 3000


